// CMSC 350 Data Structures and Analysis
// Week 4 Examples
// Dr. Duane J. Jarc
// March 1, 2020

// This class defines an unchecked exception that is thrown when a multilevel
// list is input that has an invalid syntax.

package list;

public class InvalidListSyntax extends RuntimeException
{
}
