// CMSC 350 Data Structures and Analysis
// Week 2 Examples
// Dr. Duane J. Jarc
// March 1, 2020

// This class defines a check exception that is thrown when division by 0
// is attempted in the program that evaluates postfix expressions.

package stack;

public class DivideByZero extends Exception
{
}
